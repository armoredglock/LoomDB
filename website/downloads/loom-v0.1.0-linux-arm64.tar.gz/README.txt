LoomDB v0.1.0 for linux-arm64. Run: chmod +x install.sh && ./install.sh
