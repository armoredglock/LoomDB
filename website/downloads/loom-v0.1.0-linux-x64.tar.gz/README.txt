LoomDB v0.1.0 for linux-x64. Run: chmod +x install.sh && ./install.sh
