LoomDB v0.1.0 for darwin-x64. Run: chmod +x install.sh && ./install.sh
